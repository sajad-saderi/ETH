#!/bin/sh
echo 'nameserver 192.168.87.30' > /etc/resolv.conf